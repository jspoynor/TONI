# Nemo: OpenAI document comparison and follow-ups

This package adds actual OpenAI document reading to the existing local extraction/rules prototype. All data is fictional CareFlow sample data. No company submission was made.

Start with **SCAN_REPORT.md** for observed results and API usage, then **FORM_AND_RULES.md** for the form and behavior contract.

## Included

- `pipeline.py`: two separate OpenAI requests per document: saved local page text and rendered original page images. The model sees no answer keys or target reporting period. Code selects the reporting period afterward.
- `model_rules.md`, `reading.schema.json`: the extraction instructions and strict model response schema.
- `reporting.py`: the existing deterministic reporting model and validation rules.
- `question_bank.json`, `questions.py`: field-specific questions, evidence-bound question IDs, a maximum-three question queue, and structured company-answer mapping.
- `blank_form.json`, `results/*_filled_form.json`: empty UI form and populated results with provenance and status.
- `results/*_response.json`: saved paid API responses and returned usage, without API keys or request image payloads.
- `results_initial/`, `results_revision2/`: preserved development runs; these exposed omissions and prompted the per-document design. Do not confuse these earlier results with the final `results/`.
- `results/simulated_follow_up.json`: clearly labeled simulated answer showing cash filled and the queue advanced; not a real company answer.
- `sample-inputs/`: original synthetic PDFs/TXT and previously saved local extraction outputs. Developer answer keys are not included in requests.
- `test_pipeline.py`, `test_saved_scans.py`: 22 offline behavioral/regression tests for comparison, evidence, missing/unclear values and answer routing.

## Run offline

Python 3.10+:

```bash
python -m pip install -r requirements.txt
python -m unittest discover -s . -v
python analyze.py
```

`analyze.py` reprocesses saved outputs; it does not call OpenAI. It includes explicit manual expected amounts only for after-the-fact evaluation. It never supplies them to `pipeline.py`.

## Run a new paid experiment

Install Poppler (`pdftoppm`) and a DejaVuSans font, then set `OPENAI_API_KEY` in the process environment or provide a local `.env` path. Never commit it or place it in frontend code. Keep the same API key file already saved outside this package.

```bash
python pipeline.py --env-file ../.env --cases complete --results-dir results_new
```

The model is pinned to `gpt-4.1-mini-2025-04-14`, with `store=false`, no tools, no automatic retries and capped output tokens. Reusing a result is allowed only if the request fingerprint matches. Use a new result directory after changing the prompt/schema. Existing results may have a different development prompt fingerprint; use `analyze.py` to inspect them without rerunning paid calls.

This experiment has a recorded-cost guard of USD 0.50 across package `results*` folders. It is a local estimate, not an account-wide or exact spending cap; a request can add cost before the next guard check. Do not delete usage records to bypass the guard. API billing is separate from free local Tesseract extraction.

The model output is checked with Pydantic, source filename/page validation, and local quote matching where applicable. Keep null metadata null; don't “repair” it with an expected answer. The schema cannot prove extraction correctness. Original paid responses remain available even when validation fails.

## Integration boundary

Validation: the 22 new comparison/answer/scan tests pass, alongside the existing 22 reporting-rule tests run from the previous package.

The current demo binds to the CareFlow request in `pipeline.REQUEST`. Before using real companies, supply trusted company/request context and replace the demo name-substring check with a proper identity policy. Field comparison, independent-source coverage, exact quote fidelity and narrative equivalence need broader evaluation on realistic documents. A matching pair may share an omission; the first development run demonstrated this.

`questions.apply_answer` consumes typed data associated with a current question; it does not yet interpret arbitrary free-text company answers. Jackson's UI can use the filled-form JSON and question queue now. Persistent storage, authenticated users, an OpenAI answer interpreter, submission UI, scheduling and Carta integration remain separate work.

## Official references checked

- [Image inputs](https://developers.openai.com/api/docs/guides/images-vision)
- [Structured outputs](https://developers.openai.com/api/docs/guides/structured-outputs)
- [Model capabilities and token rates](https://developers.openai.com/api/docs/models/gpt-4.1-mini)

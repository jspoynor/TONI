"""Rebuild comparisons/questions from saved responses with no API calls."""
from pathlib import Path
import json
from pipeline import HERE,DEFAULT_ROOT,parsed,source_docs,make_draft,compare,assemble
from reporting import NAMES,validate
from questions import question_queue,apply_answer

def main():
 out=HERE/'results';rows=[];cost=0;calls=0
 baseline={'complete':{'revenue':[120000],'cash_on_hand':[420000],'arr':[1200000]},'scanned':{'revenue':[120000],'cash_on_hand':[420000],'arr':[1200000]},'missing':{'revenue':[120000],'cash_on_hand':[],'arr':[]},'conflict':{'revenue':[120,120000],'cash_on_hand':[420000,450000],'arr':[1200000]},'wrong_period':{'revenue':[900000],'cash_on_hand':[800000],'arr':[]}}
 md=['# OpenAI and local extraction comparison','', 'Synthetic CareFlow samples only. Model: `gpt-4.1-mini-2025-04-14`. Each document used two isolated requests: saved local text and rendered original page images. Both interpretation requests used the same model; this is independence of inputs, not independent model families. Answer keys were used only below for evaluation, never in scan requests.','', '## Final-run comparison','', '| Case | Revenue | Cash | ARR | Management | Risks | Help | Draft |','|---|---|---|---|---|---|---|---|']
 results={}
 for case in baseline:
  if not (out/f'{case}_vision_reading.json').exists():continue
  docs=source_docs(DEFAULT_ROOT,case);drafts={};prov=[]
  for reader in ('local_text','vision'):
   reading=json.loads((out/f'{case}_{reader}_reading.json').read_text());drafts[reader],p=make_draft(reading,reader,docs);prov+=p
  comp=compare(drafts['local_text'],drafts['vision']);combined=assemble(drafts['local_text'],drafts['vision'],comp);report=validate(combined);queue=question_queue(report,comp)
  # Use question-bank wording in the UI-ready view, retaining the original deterministic field statuses.
  report['questions']=queue['questions'];report['remaining_question_count']=len(queue['remaining'])
  a={'case':case,'comparison':comp,'draft':combined,'report':report,'question_queue':queue,'provenance':prov}
  (out/f'{case}_comparison.json').write_text(json.dumps(a,indent=2));results[case]=a
  form={'company':'Nemo Demo CareFlow Co.','request':report['request'],'status':report['status'],'fields':{n:{'value':f['value'],'status':f['status'],'issues':f['issues'],'evidence':f['candidates'],'confirmed':False} for n,f in report['fields'].items()},'questions':queue['questions'],'remaining_question_count':len(queue['remaining']),'company_confirmed':False}
  (out/f'{case}_filled_form.json').write_text(json.dumps(form,indent=2))
  md.append('| '+case+' | '+' | '.join(comp[n]['comparison'] for n in NAMES)+' | '+report['status']+' |')
  for reader,d in drafts.items():
   for field,expected in baseline[case].items():
    got=sorted(set(c['value'] for c in d['fields'][field]['candidates']))
    rows.append({'case':case,'reader':reader,'field':field,'expected_amounts':expected,'observed_amounts':got,'amount_set_matches':got==expected})
 md+=['','## Check against the manually authored baseline','','These checks compare amount sets only. Field validation separately checks currency, units, dates, definition and evidence uncertainty. They are a small fixture evaluation, not a general OCR accuracy score.','']
 failures=[r for r in rows if not r['amount_set_matches']]
 md.append(f'{len(rows)-len(failures)}/{len(rows)} amount-set checks matched the baseline.')
 for r in failures:md.append(f'- {r["case"]}/{r["reader"]}/{r["field"]}: expected {r["expected_amounts"]}, got {r["observed_amounts"]}.')
 for case,a in results.items():
  md+=['',f'## {case}: form and follow-ups','', '| Field | Accepted draft value | Status |','|---|---|---|']
  for n,f in a['report']['fields'].items():
   value='Not accepted / not provided' if f['value'] is None else str(f['value'])
   md.append('| '+n+' | '+value.replace('|','\\|')+' | '+f['status']+' |')
  for q in a['question_queue']['questions']:md.append(f'- **{q["field"]} ({q["reason"]}):** {q["question"]}')
  if a['question_queue']['remaining']:md.append(f'- {len(a["question_queue"]["remaining"])} additional questions stay queued; maximum three shown at once.')
  warnings=[]
  for reader in ('local_text','vision'):warnings.extend(json.loads((out/f'{case}_{reader}_reading.json').read_text())['warnings'])
  if warnings:md.append('- Reader warnings: '+'; '.join(warnings))
  issues={n:f['issues'] for n,f in a['report']['fields'].items() if f['issues']}
  if issues:md.append('- Validation issues: `'+json.dumps(issues)+'`')
 if 'missing' in results:
  a=results['missing'];q=next(q for q in a['question_queue']['questions'] if q['field']=='cash_on_hand')
  demo=apply_answer(a['draft'],q,{'value':420000,'currency':'USD','unit':'base_units','as_of_date':'2026-08-31'},message_id='SIMULATED-finance-answer-1',quote='SIMULATED ANSWER: Our cash was USD 420,000 in whole dollars as of August 31, 2026.',comparison=a['comparison'])
  demo['simulation_only']=True;(out/'simulated_follow_up.json').write_text(json.dumps(demo,indent=2))
  md+=['','## Simulated answer round trip','','In the missing case, a labeled simulated company answer fills cash at USD 420,000 as of August 31. Only the cash field changes; other unanswered fields remain queued. The report remains unconfirmed. See `results/simulated_follow_up.json`. This demonstration uses a structured answer, not a live natural-language answer interpreter.']
 for folder in ('results_initial','results_revision2','results'):
  for p in (HERE/folder).glob('*_response.json'):
   r=json.loads(p.read_text());cost+=r['estimated_usd'];calls+=1
 md+=['','## Usage and limitations','',f'{calls} paid API responses across all three development runs. Estimated total: **USD {cost:.6f}**. Calculated from returned token usage at $0.40/M uncached input, $0.10/M cached input and $1.60/M output; this is an estimate, not a billing receipt. Model pricing checked September 19, 2026: https://developers.openai.com/api/docs/models/gpt-4.1-mini','', 'The first run caught blank narrative values and conservative date/quote issues. The second run also demonstrated shared omissions: both readings skipped the ambiguous note and annual figures. The final per-document extraction removed the target request from model input and recovered those amounts; missing units and other differences still require follow-up. Its original responses are retained in `results_initial`. The revised schema requires nonempty narrative values. The adapter normalizes whitespace and hyphen line wraps, removes redundant ARR “defined as” framing, and ignores numeric-only metadata slots on narrative fields while retaining raw model responses. It does not use expected answers to repair output.','', 'The sample PDFs are clean synthetic documents. Visual evidence citations still require human review; text substring checks cannot prove that a number or date is interpreted correctly. Two readings may share errors. This is a field-extraction comparison, not a full verbatim OCR accuracy test. Production identity checks, UI wiring, persistent audit storage, recurring scheduling and live conversational answer interpretation remain future work. No report has been submitted.']
 (HERE/'SCAN_REPORT.md').write_text('\n'.join(md)+'\n');(out/'baseline_evaluation.json').write_text(json.dumps(rows,indent=2));(out/'usage_summary.json').write_text(json.dumps({'paid_responses':calls,'estimated_usd':cost,'amount_checks':len(rows),'matched_amount_checks':len(rows)-len(failures)},indent=2))
 print(json.dumps({'cases':{c:a['report']['status'] for c,a in results.items()},'amount_checks':len(rows),'matched':len(rows)-len(failures),'estimated_usd':cost},indent=2))
if __name__=='__main__':main()

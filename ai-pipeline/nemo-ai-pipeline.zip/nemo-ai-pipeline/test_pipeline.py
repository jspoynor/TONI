import unittest
from copy import deepcopy
from pipeline import compare,assemble,REQUEST,make_draft,norm
from reporting import NAMES,validate
from questions import question_queue,apply_answer

def empty():return {'request':deepcopy(REQUEST),'fields':{n:{'candidates':[]} for n in NAMES}}
def cash(value=420000):return {'id':'local-cash','company_id':REQUEST['company_id'],'request_id':REQUEST['request_id'],'value':value,'currency':'USD','unit':'base_units','period_start':None,'period_end':None,'as_of_date':'2026-08-31','definition':None,'source':{'kind':'document','file':'test.pdf','page':1,'quote':'Cash 420000','uncertain':False}}
class PipelineTests(unittest.TestCase):
 def test_equal_values_different_currency_disagree(self):
  a=empty();b=empty();a['fields']['cash_on_hand']['candidates']=[cash()];b['fields']['cash_on_hand']['candidates']=[cash()];b['fields']['cash_on_hand']['candidates'][0]['currency']='EUR'
  self.assertEqual(compare(a,b)['cash_on_hand']['comparison'],'disagreement')
 def test_missing_reader_blocks(self):
  a=empty();b=empty();a['fields']['cash_on_hand']['candidates']=[cash()]
  c=compare(a,b);self.assertEqual(c['cash_on_hand']['comparison'],'one_reader_missing')
  self.assertIn('source_uncertain',validate(assemble(a,b,c))['fields']['cash_on_hand']['issues'])
 def test_both_missing_not_zero(self):
  a=empty();self.assertEqual(compare(a,a)['revenue']['comparison'],'both_missing');self.assertIsNone(validate(a)['fields']['revenue']['value'])
 def test_question_cap_and_field_mapping(self):
  q=question_queue(validate(empty()));self.assertEqual(len(q['questions']),3);self.assertEqual(len(q['remaining']),3)
  for x in q['questions']:self.assertEqual(x['write_path'],'fields.'+x['field'])
 def test_conflict_first(self):
  a=empty();a['fields']['cash_on_hand']['candidates']=[cash(),dict(cash(450000),id='vision-cash')]
  q=question_queue(validate(a))['questions'][0];self.assertEqual((q['field'],q['reason']),('cash_on_hand','conflict'));self.assertEqual(len(q['candidate_options']),2)
 def test_company_answer_preserves_evidence(self):
  a=empty();a['fields']['cash_on_hand']['candidates']=[cash(),dict(cash(450000),id='vision-cash')];q=question_queue(validate(a))['questions'][0]
  result=apply_answer(a,q,{'value':420000,'currency':'USD','unit':'base_units','as_of_date':'2026-08-31'},message_id='m1',quote='Cash was USD 420000 at August 31.')
  self.assertEqual(len(result['draft']['fields']['cash_on_hand']['candidates']),3);self.assertEqual(result['report']['fields']['cash_on_hand']['value'],420000);self.assertFalse(result['report']['confirmed']);self.assertEqual(len(a['fields']['cash_on_hand']['candidates']),2)
 def test_stale_question_rejected(self):
  a=empty();q=question_queue(validate(a))['questions'][0];a['request']['period_end']='2026-09-01'
  with self.assertRaises(ValueError):apply_answer(a,q,{'value':1},message_id='m',quote='one')
 def test_answer_cannot_change_other_fields(self):
  a=empty();q=question_queue(validate(a))['questions'][0]
  with self.assertRaises(ValueError):apply_answer(a,q,{'value':1,'cash_on_hand':100},message_id='m',quote='one')
 def test_bad_date_answer_stays_unresolved(self):
  a=empty();q=question_queue(validate(a))['questions'][0]
  result=apply_answer(a,q,{'value':1,'currency':'USD','unit':'base_units','period_start':'2025-01-01','period_end':'2025-12-31'},message_id='m',quote='annual one')
  self.assertEqual(result['report']['fields']['revenue']['status'],'needs_clarification')
 def test_unmatched_quote_marked_uncertain(self):
  e={k:cash()[k] for k in ('value','currency','unit','period_start','period_end','as_of_date','definition')};e.update(file='test.pdf',page=1,quote='not in text',metadata_evidence='',uncertain=False)
  reading={'company_name':'CareFlow',**{n:[] for n in NAMES},'warnings':[]};reading['cash_on_hand']=[e]
  d,_=make_draft(reading,'local_text',[{'file':'test.pdf','pages':[{'page':1,'text':'Cash 420000'}]}]);self.assertTrue(d['fields']['cash_on_hand']['candidates'][0]['source']['uncertain'])
 def test_unknown_source_rejected(self):
  e={k:cash()[k] for k in ('value','currency','unit','period_start','period_end','as_of_date','definition')};e.update(file='invented.pdf',page=1,quote='x',metadata_evidence='',uncertain=False)
  reading={'company_name':'CareFlow',**{n:[] for n in NAMES},'warnings':[]};reading['cash_on_hand']=[e]
  with self.assertRaises(ValueError):make_draft(reading,'vision',[])
 def test_wrong_company_rejected(self):
  reading={'company_name':'Another company',**{n:[] for n in NAMES},'warnings':[]}
  with self.assertRaises(ValueError):make_draft(reading,'vision',[])

class NormalizationTests(unittest.TestCase):
 def test_hyphen_wrap_normalized_without_removing_hyphen(self):
  self.assertEqual(norm('Management-\nreported ARR'), 'Management-reported ARR')
 def test_narrative_numeric_slots_do_not_create_false_conflicts(self):
  reading={'company_name':'CareFlow',**{n:[] for n in NAMES},'warnings':[]}
  e={'value':'Growth from deployment.','currency':'USD','unit':'base_units','period_start':'2026-08-01','period_end':'2026-08-31','as_of_date':None,'definition':None,'file':'test.pdf','page':1,'quote':'Growth from deployment.','metadata_evidence':'','uncertain':False}
  reading['management_context']=[e];d,_=make_draft(reading,'vision',[{'file':'test.pdf','pages':[{'page':1,'text':'Growth from deployment.'}]}])
  self.assertIsNone(d['fields']['management_context']['candidates'][0]['currency'])
 def test_unknown_period_candidate_survives_current_period_selection(self):
  reading={'company_name':'CareFlow',**{n:[] for n in NAMES},'warnings':[]}
  def ev(value,start,end):return {'value':value,'currency':'USD','unit':'base_units','period_start':start,'period_end':end,'as_of_date':None,'definition':None,'file':'test.pdf','page':1,'quote':'revenue','metadata_evidence':'','uncertain':False}
  reading['revenue']=[ev(10,'2026-08-01','2026-08-31'),ev(8,'2026-07-01','2026-07-31'),ev(12,None,None)]
  d,_=make_draft(reading,'vision',[{'file':'test.pdf','pages':[{'page':1,'text':'revenue'}]}]);self.assertEqual([c['value'] for c in d['fields']['revenue']['candidates']],[10,12])
 def test_only_wrong_period_is_retained_and_rejected(self):
  reading={'company_name':'CareFlow',**{n:[] for n in NAMES},'warnings':[]}
  reading['cash_on_hand']=[{'value':90,'currency':'USD','unit':'base_units','period_start':None,'period_end':None,'as_of_date':'2025-12-31','definition':None,'file':'test.pdf','page':1,'quote':'cash','metadata_evidence':'','uncertain':False}]
  d,_=make_draft(reading,'vision',[{'file':'test.pdf','pages':[{'page':1,'text':'cash'}]}]);self.assertEqual(len(d['fields']['cash_on_hand']['candidates']),1);self.assertIn('as_of_date_missing_or_wrong',validate(d)['fields']['cash_on_hand']['issues'])

if __name__=='__main__':unittest.main()

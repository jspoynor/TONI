"""Regression checks on saved live outputs. No network calls or additional cost."""
import json,unittest
from pathlib import Path
from questions import question_queue
from reporting import Draft
P=Path(__file__).parent/'results'
def load(case):return json.loads((P/f'{case}_comparison.json').read_text())
class SavedScanTests(unittest.TestCase):
 def test_baseline_amount_sets(self):
  rows=json.loads((P/'baseline_evaluation.json').read_text());self.assertEqual(len(rows),30);self.assertTrue(all(r['amount_set_matches'] for r in rows))
 def test_document_conflict_not_accepted_despite_reader_agreement(self):
  r=load('conflict');f=r['report']['fields']['cash_on_hand'];self.assertIsNone(f['value']);self.assertEqual(f['status'],'conflicting');self.assertEqual({c['value'] for c in f['candidates']},{420000,450000})
 def test_wrong_period_values_retained_but_rejected(self):
  r=load('wrong_period')['report'];self.assertIn('reporting_period_missing_or_wrong',r['fields']['revenue']['issues']);self.assertIn('as_of_date_missing_or_wrong',r['fields']['cash_on_hand']['issues']);self.assertIsNone(r['fields']['revenue']['value'])
 def test_matching_amount_unclear_units_asks_about_units(self):
  r=load('complete');queue=question_queue(r['report'],r['comparison']);q=next(x for x in queue['questions'] if x['field']=='cash_on_hand');self.assertEqual(q['reason'],'units')
 def test_missing_cash_answer_changes_only_cash(self):
  before=Draft.model_validate(load('missing')['draft']).model_dump(mode='json');after=json.loads((P/'simulated_follow_up.json').read_text())
  self.assertTrue(after['simulation_only']);self.assertFalse(after['report']['confirmed']);self.assertEqual(after['report']['fields']['cash_on_hand']['value'],420000)
  for n in before['fields']:
   if n!='cash_on_hand':self.assertEqual(before['fields'][n],after['draft']['fields'][n])
 def test_no_scan_auto_submits(self):
  for case in ['complete','scanned','missing','conflict','wrong_period']:
   r=load(case)['report'];self.assertFalse(r['confirmed']);self.assertNotEqual(r['status'],'submitted');self.assertLessEqual(len(r['questions']),3)
if __name__=='__main__':unittest.main()
